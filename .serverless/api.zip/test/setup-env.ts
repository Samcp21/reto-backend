process.env.NODE_ENV = 'production';
process.env.PEOPLE_TABLE = 'reto-backend-dev-PeopleTable';
process.env.HISTORY_TABLE = 'reto-backend-dev-HistoryTable';
process.env.EVENT_BUS_NAME = 'reto-backend-dev-event-bus';
process.env.AWS_REGION = 'us-east-2';
