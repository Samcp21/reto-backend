export * from './people.controller';
export * from './seed.controller';
